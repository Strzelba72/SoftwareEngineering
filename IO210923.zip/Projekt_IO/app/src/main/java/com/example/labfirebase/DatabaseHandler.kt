package com.example.labfirebase

object DatabaseHandler {
}