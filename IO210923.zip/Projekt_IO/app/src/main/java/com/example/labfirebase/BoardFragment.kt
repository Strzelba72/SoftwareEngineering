package com.example.labfirebase

import android.os.Bundle
import android.service.autofill.OnClickAction
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.navArgs
import com.example.labfirebase.Deck.cards
import com.example.labfirebase.databinding.FragmentBoardBinding

class BoardFragment : Fragment() {

    private lateinit var binding: FragmentBoardBinding
    private val args: BoardFragmentArgs by navArgs()

    private val initialDrawNumber: Int = 9

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentBoardBinding.inflate(inflater, container, false)

        initialDraw()
        binding.playerCard1.setOnClickListener{
            playerCardImgIdsArrayINVISIBLE(1)


        }
        binding.playerCard2.setOnClickListener{
            playerCardImgIdsArrayINVISIBLE(2)
        }
        binding.playerCard3.setOnClickListener{
            playerCardImgIdsArrayINVISIBLE(3)
        }
        binding.playerCard4.setOnClickListener{
            playerCardImgIdsArrayINVISIBLE(4)
        }
        binding.playerCard5.setOnClickListener{
            playerCardImgIdsArrayINVISIBLE(5)
        }
        binding.playerCard6.setOnClickListener{
            playerCardImgIdsArrayINVISIBLE(6)
        }
        binding.playerCard7.setOnClickListener{
            playerCardImgIdsArrayINVISIBLE(7)
        }
        binding.playerCard8.setOnClickListener{
            playerCardImgIdsArrayINVISIBLE(8)
        }
        binding.playerCard9.setOnClickListener{
            playerCardImgIdsArrayINVISIBLE(9)
        }
        binding.enemyCard1.setOnClickListener{
            enemyCardImgIdsArrayINVISIBLE(1)
        }
        binding.enemyCard2.setOnClickListener{
            enemyCardImgIdsArrayINVISIBLE(2)
        }
        binding.enemyCard3.setOnClickListener{
            enemyCardImgIdsArrayINVISIBLE(3)
        }
        binding.enemyCard4.setOnClickListener{
            enemyCardImgIdsArrayINVISIBLE(4)
        }
        binding.enemyCard5.setOnClickListener{
            enemyCardImgIdsArrayINVISIBLE(5)
        }
        binding.enemyCard6.setOnClickListener{
            enemyCardImgIdsArrayINVISIBLE(6)
        }
        binding.enemyCard7.setOnClickListener{
            enemyCardImgIdsArrayINVISIBLE(7)
        }
        binding.enemyCard8.setOnClickListener{
            enemyCardImgIdsArrayINVISIBLE(8)
        }
        binding.enemyCard9.setOnClickListener{
            enemyCardImgIdsArrayINVISIBLE(9)
        }


        return binding.root
    }

    private fun initialDraw() {
        for (num in 1..initialDrawNumber) {

            playerCardImgIdsArray(num)
            enemyCardImgIdsArray(num)


       }
    }



    private fun playerCardImgIdsArray(num: Int)
    {
        when(num)
        {
            1->binding.playerCard1.visibility=View.VISIBLE
            2->binding.playerCard2.visibility=View.VISIBLE
            3->binding.playerCard3.visibility=View.VISIBLE
            4->binding.playerCard4.visibility=View.VISIBLE
            5->binding.playerCard5.visibility=View.VISIBLE
            6->binding.playerCard6.visibility=View.VISIBLE
            7->binding.playerCard7.visibility=View.VISIBLE
            8->binding.playerCard8.visibility=View.VISIBLE
            9->binding.playerCard9.visibility=View.VISIBLE
        }
    }
    private fun playerCardImgIdsArrayINVISIBLE(num: Int)
    {
        when(num)
        {
            1->binding.playerCard1.visibility=View.INVISIBLE
            2->binding.playerCard2.visibility=View.INVISIBLE
            3->binding.playerCard3.visibility=View.INVISIBLE
            4->binding.playerCard4.visibility=View.INVISIBLE
            5->binding.playerCard5.visibility=View.INVISIBLE
            6->binding.playerCard6.visibility=View.INVISIBLE
            7->binding.playerCard7.visibility=View.INVISIBLE
            8->binding.playerCard8.visibility=View.INVISIBLE
            9->binding.playerCard9.visibility=View.INVISIBLE
        }
    }
    private fun enemyCardImgIdsArray(num: Int)
    {
        when(num)
        {
            1->binding.enemyCard1.visibility=View.VISIBLE
            2->binding.enemyCard2.visibility=View.VISIBLE
            3->binding.enemyCard3.visibility=View.VISIBLE
            4->binding.enemyCard4.visibility=View.VISIBLE
            5->binding.enemyCard5.visibility=View.VISIBLE
            6->binding.enemyCard6.visibility=View.VISIBLE
            7->binding.enemyCard7.visibility=View.VISIBLE
            8->binding.enemyCard8.visibility=View.VISIBLE
            9->binding.enemyCard9.visibility=View.VISIBLE
        }
    }
    private fun enemyCardImgIdsArrayINVISIBLE(num: Int)
    {
        when(num)
        {
            1->binding.enemyCard1.visibility=View.INVISIBLE
            2->binding.enemyCard2.visibility=View.INVISIBLE
            3->binding.enemyCard3.visibility=View.INVISIBLE
            4->binding.enemyCard4.visibility=View.INVISIBLE
            5->binding.enemyCard5.visibility=View.INVISIBLE
            6->binding.enemyCard6.visibility=View.INVISIBLE
            7->binding.enemyCard7.visibility=View.INVISIBLE
            8->binding.enemyCard8.visibility=View.INVISIBLE
            9->binding.enemyCard9.visibility=View.INVISIBLE
        }
    }
    private fun playerDraw()
    {
        //binding.playerCard1.setImageResource(R.drawable.cards)
    }



}
